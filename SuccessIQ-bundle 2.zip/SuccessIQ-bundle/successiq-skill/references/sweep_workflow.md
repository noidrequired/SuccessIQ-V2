# SuccessIQ Sweep Workflow

A sweep is a structured review of recent activity across Outlook, Slack, and Zoom to update the SuccessIQ task database. Run it daily or every 48 hours to stay current.

---

## Step 0 — Establish the Time Window

Default: last 48 hours. Honor whatever the user specifies ("last 7 days", "since Monday", "last 72 hours").

State the window explicitly before searching: "Running sweep for May 17 2026 14:00 UTC → May 19 2026 14:00 UTC."

---

## Step 1 — Load the Database

Read the user's `successiq.json` file. Confirm the current state:
- Total tasks, open tasks
- Total contacts, total customers
- Date of last sweep (`meta.last_sweep`)

If the file doesn't exist, ask the user to initialize first (`init` command).

---

## Step 2 — Search Outlook (Received)

Use `outlook_email_search` to search the inbox for the sweep window.

**Search strategy** — run multiple targeted searches rather than one broad one:
- By known customer domain names (e.g., `"from:acme.com"`)
- By known contact names
- By product-related terms (support tickets, escalations, NPS, invoice)
- By CSM's own name (to find emails where they're CC'd)

**What to extract from each email:**
- Date, sender, subject, key content
- Any action items, commitments, questions, or decisions
- Any new people (potential new contacts)
- Any signals about customer sentiment, blockers, or milestones

---

## Step 3 — Search Outlook (Sent)

Use `outlook_email_search` with `sender:[csm email address]` for the sweep window.

This step is **mandatory and equally weighted** as received mail. Sent emails reveal the CSM's own commitments, next steps promised, and internal escalations raised — all of which generate tasks. Don't treat this as a lower-priority pass.

Look for:
- Promises made ("I'll send you X by…", "I'll coordinate with…")
- Meeting follow-up emails and summaries sent to customers
- Proposals, quotes, or templates shared
- Escalations or requests raised internally (PS requests, engineering asks, management loops)
- Any new contacts CC'd or introduced

---

## Step 3b — Search Outlook (Clari Post-Call Summaries)

Use `outlook_email_search` with `sender:notifications@clari.com` for the sweep window.

This is a **dedicated, required search** — do not rely on Clari emails being caught incidentally during general inbox search. Clari sends a structured post-call summary email after every Teams or Zoom meeting that was AI-summarised. These contain:

- A full meeting summary paragraph
- An explicit **Action Items** list (often with owner attribution)
- Attendees, call duration, deal context
- Decisions made and next steps committed to verbally

Why this matters: commitments made in a 4-minute Teams call may never appear in any other email thread. The Clari summary is the only written record. Skipping this step means those action items don't become tasks — and they get dropped.

**How to process a Clari summary:**
1. Read the full email body (not just the subject)
2. Extract each action item as a candidate task
3. Cross-check against existing open tasks before creating new ones
4. Use `[YYYY-MM-DD MEETING]` as the note tag (not `SWEEP`) to signal this came from a call

---

## Step 4 — Search Slack

Use `slack_search_public_and_private` for the sweep window.

**Search strategy:**
- Customer names (try both full name and short slug)
- Contact names
- Account keywords (e.g., "Acme renewal", "Sagemcom NDA", "Maaden go-live")
- CSM-tagged messages (`@[csm name]`)
- Account Slack channels if they exist (e.g., `#acct-acme`)

Extract: dates, thread context, action items, decisions, new people, sentiment signals.

---

## Step 5 — Check Zoom

Use `recordings_list` to list recent meetings in the window.

For each meeting that involves customers:
1. Call `get_meeting_assets` to retrieve notes, transcript summary, or action items
2. Extract: attendees (especially new contacts), decisions, action items, follow-up commitments, blockers raised

Zoom notes are a rich source for new tasks — Clari-style meeting notes often contain explicit action items.

---

## Step 6 — Analyze Findings

Organize all findings into five categories:

### A — New Contacts
People who appear in emails/Slack/Zoom but are not yet in the contacts array.
- Need: name, email, customer, role, title

### B — Task Closures
Evidence that an existing open task has been resolved.
- Email confirming payment received → close overdue invoice task
- Meeting notes showing go-live completed → close implementation milestone task
- "Confirmed no further action needed" → close follow-up task

### C — Task Updates
Existing open tasks that need date changes, note additions, or `next` updates.
- Due date bumped because milestone slipped
- New context from a call that changes what the next action is
- Evidence task is blocked (add to notes; set priority accordingly)

### D — New Tasks
Actions that aren't tracked yet but need to be.
- Action item committed to in a Zoom call
- Question from customer that needs a formal follow-up
- New escalation or risk signal
- Upcoming renewal / implementation milestone approaching

### E — Customer Summary Updates
The customer's `summary` field needs refreshing based on new evidence.
- `stage` changed (Steady → At-risk, or At-risk → Expansion) — only on real evidence, see Step 6b below
- Key contact left or changed roles
- Major milestone reached
- Material change in usage, health, or relationship status

---

## Step 6b — Apply the CS Methodology (required, every finding)

Before writing the patch script, run every new task and every proposed `stage` change through Lincoln Murphy's framework (`cs_methodology.md`). This step is not optional and is not satisfied just by filling in the right JSON fields:

- **Every new task's `ctx`** must name the customer's Required Outcome and how this task serves or unblocks it — not just restate the triggering email.
- **Every task's `pri`** must follow from Required Outcome / Success Vector status (see the priority table in `SKILL.md` / `schema.md`), not from how urgent the email sounded.
- **Any proposed `stage` change** must be grounded in a Success Vector pattern (direction, not a single data point) — one good or bad email is not enough evidence.
- If a sweep surfaces a new or changed business goal, update `summary` to capture the Desired Outcome itself, not just the activity that revealed it.

---

## Step 7 — Write and Execute the Patch Script

Build one Python patch script covering all findings from Steps A–E, already reframed through Step 6b.

Name the script clearly: `patch_[date]_sweep.py` (e.g., `patch_2026-05-19_sweep.py`).

Use the patch script template from `SKILL.md`. Key points:
- `LABEL = "sweep"` in the backup filename
- Process in this order: contacts → closures → updates → new tasks → summary/stage updates
- One `changes.append()` line per mutation, with a clear description
- Always include the 30-day backup cleanup block
- Append one `auditLog` entry summarizing the sweep (see `schema.md` for the `auditLog` shape and the `next_audit_id()` helper)
- Update `data["exported"]` to the current ISO timestamp (there is no `meta.last_sweep` in this schema)

Run via Bash. Show the full output (changes list + verify line) to the user.

---

## Step 8 — Report

Summarize results clearly:

```
SWEEP COMPLETE — [N] changes
  • [N] new contacts added
  • [N] tasks closed
  • [N] tasks updated
  • [N] new tasks created
  • [N] customer summaries updated

Database: [X] total tasks, [Y] open | [Z] contacts | [W] customers
Backup: [path]
```

Then offer a brief status view: "Want me to show your P0/P1 open items?" This is often the natural next step after a sweep.

---

## Sweep Quality Rules

**Completeness over speed**: It's better to catch every signal and take a few extra minutes than to miss an AT RISK flag. If in doubt about a contact or task, include it.

**Three Outlook searches, every time**: Received mail, sent mail, and Clari summaries are all mandatory — not optional passes. Each reveals a different class of signal that the others won't catch.

**Sent emails are often more important than received**: The CSM's sent folder shows commitments they've made — these generate tasks.

**Clari summaries are the richest action-item source**: A 4-minute call can produce 3–4 concrete action items that will never appear in any inbox thread. Always check `from:notifications@clari.com` explicitly — don't assume the general inbox search will surface them.

**One source → one task per action**: If a Zoom call generated 3 action items, create 3 tasks. Don't bundle unrelated items.

**Don't create duplicate tasks**: Before creating a new task, scan for similar open tasks for the same customer. If one already exists, update it; don't create a duplicate.

**Close conservatively**: Only close a task if there is clear evidence of resolution (email confirmation, meeting notes, explicit statement). "No recent activity" is not evidence of closure.

**`stage` updates are editorial**: Update `stage` only when the evidence clearly supports the change. Don't flip to `At-risk` from one bad email; don't flip to `Healthy`/`Expansion` from one good one. Look for patterns. (`sentiment` is a separate Green/Yellow/Red indicator — don't conflate the two.)

---

## Sweep Cadence Recommendations

| Cadence | Best for |
|---------|---------|
| Daily | Active implementations, AT RISK accounts, renewal crunch |
| Every 48h | Stable portfolio with regular cadence |
| Weekly | Low-activity periods, vacation catch-up |
| Ad hoc | Post-QBR, post-EBR, post-incident |

Consider setting a scheduled task (via the `schedule` skill) to run the sweep automatically each morning.
