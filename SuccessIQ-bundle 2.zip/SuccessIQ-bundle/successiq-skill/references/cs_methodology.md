# CS Methodology — Lincoln Murphy / Sixteen Ventures

This is the operating framework behind every SuccessIQ task, priority, and customer assessment. All credit to Lincoln Murphy of Sixteen Ventures (sixteenventures.com).

---

## The Core Definition

> "Customer Success is when your customers achieve their **Desired Outcome** through their interactions with your company."

CS exists for one reason: get customers to **stay longer, buy more, and advocate**. This drives NRR, compounds LTV, and makes CAC more efficient.

---

## Framework 1 — Desired Outcome

**Desired Outcome = Required Outcome + Appropriate Experience**

- **Required Outcome**: What the customer *needs* to achieve — their business goal, not a feature request. "Reduce carrier ETA variance for shipment planning" is a Required Outcome. "Fix the ETA accuracy bug" is not.
- **Appropriate Experience**: *How* they need to achieve it — congruent with their expectations, resources, and context. An enterprise customer mid-implementation needs high-touch, responsive, proactive engagement. A self-sufficient API-first customer may prefer autonomy.

**How to apply in SuccessIQ:**
- Every task's `ctx` field should name the Required Outcome
- A customer complaining about a feature is signaling their Required Outcome is blocked — treat it as P0 or P1
- When you don't know the Required Outcome, that itself is a task: schedule a discovery call

---

## Framework 2 — Goal Discovery (5W+1H)

> "No Goals = No Customer Success. Know Goals = Know Customer Success."

For every customer relationship, know:
- **What**: The specific actionable goal ("reduce carrier ETA variance to <2h for shipment planning")
- **When**: Timeframe and urgency ("before Q3 go-live", "by contract renewal August 15")
- **Why**: Consequences of not achieving it — what does churn / failure look like for them?
- **Who**: Stakeholders — who is the Economic Buyer, Champion, User, and Executive Sponsor?
- **Where**: Current state / baseline — where are they now vs. where they need to be?
- **How**: Joint accountability — what will the vendor do, and what must the customer do?

**In SuccessIQ**: Discovery is continuous. Goals evolve. Every QBR, kick-off, and renewal conversation is a chance to update `desired_outcome`. If `desired_outcome` is blank, that's a gap.

---

## Framework 3 — Success Vector

**Direction + magnitude** — not a moment-in-time health score.

| Status | Meaning | SuccessIQ Action |
|--------|---------|-----------------|
| **Positive** | Engaging, progressing toward Required Outcome, expanding logically | Nurture; watch for upsell milestone |
| **Neutral** | Stalled or renewing flat; not growing | Re-engagement task; diagnose why |
| **Negative** | Off track; Required Outcome at risk; signals emerging | Intervene now; root-cause before responding |
| **Ghost** | Key contact dark; no response to outreach | P0 task; escalate; flag churn risk |

**Key inputs to Success Vector:**
1. Success Milestones — is the customer progressing toward their Required Outcome?
2. Joint Accountabilities — are they doing their part? Are we doing ours?
3. Expansion velocity — are they growing? No expansion after 6+ months = Neutral warning
4. Support signal — unresolved escalations = Negative; no tickets after heavy usage = suspicious
5. Account health signals — M&A, budget changes, key contact departures

---

## Framework 4 — Success Potential (Pre-condition)

Six fit dimensions that CS cannot compensate for if missing:

| Dimension | Question |
|-----------|---------|
| Technical Fit | Do they have (or can acquire) required technical infrastructure? |
| Functional Fit | Does the product actually do what they need it to do? |
| Resource Fit | Can they invest beyond the subscription fee (people, time, budget)? |
| Competence Fit | Do they have internal expertise to succeed with this product? |
| Experience Fit | Do they have relevant experience with this type of solution? |
| Cultural Fit | Do their working values align with the partnership model? |

**Implication**: When a customer repeatedly fails to engage, misses milestones, or churns despite CS effort — check Success Potential. Bad-fit acquisition is a Sales problem, not a CS problem. Document it; don't keep pouring CS resources into a bad-fit account.

---

## Framework 5 — The Three Structural CS Failures

**Failure #1 — The Broken Premise**: Traditional CS was built around getting customers to do things they don't want to do. The better question: *"What complexity can we absorb from the customer so they can achieve their outcome more easily?"* → Tasks should emphasize what *we* will do, not just what we'll ask them to do.

**Failure #2 — Best People Doing Wrong Work**: CSMs buried in health score reviews, QBR slide prep, and admin instead of high-judgment relationship work. SuccessIQ is designed to automate the tracking and surfacing, freeing the CSM for conversations that require human judgment.

**Failure #3 — Tools Boxed Us In**: CS software forces teams to work how the tool works. SuccessIQ is outcome-first — if the JSON doesn't fit a situation, adapt it.

---

## Framework 6 — Churn Philosophy

> "Churn is a symptom, not a disease."

**Root causes:**
- Bad-fit acquisition (Sales problem — seeded before CS ever touched it)
- Wrong expectations set at sale (Handoff problem)
- Failure to achieve Required Outcome (CS problem)
- Inappropriate experience for the customer's context (also CS problem)

**The two and only two reasons customers churn:**
1. They can't achieve their Required Outcome with the product
2. The experience isn't appropriate for their expectations and context

**In SuccessIQ**: AT RISK tasks should note which reason applies. "Proactive retention" = intervene before the signal appears. "Reactive retention" = respond to the signal. Discounts don't save customers — value realization does.

---

## Framework 7 — Expansion Philosophy

> "Expansion is logical, not a sales motion bolted on."

- Lack of expansion is a warning signal (Neutral → Negative Vector risk)
- Anti-shrink (holding flat) is NOT growth
- Expansion should follow a Success Milestone — when they hit one, the upsell should feel logical and expected, not a pitch
- Never upsell an unsuccessful customer on more of the same product. Help them succeed first.

**In SuccessIQ**: When a customer hits a milestone, create an expansion task. Renewal tasks should demonstrate value, not just manage contract dates. Ask: what would 10-20% growth look like for this account, and what milestone unlocks it?

---

## Framework 8 — Appropriate Experience (AX) Model

Replace high-touch / low-touch / no-touch tiers with **Appropriate Experience**:
- The right engagement level is determined by what the customer's situation demands, not by ARR tier
- An enterprise customer mid-implementation needs high-touch regardless of ARR
- A self-sufficient API-first customer may prefer low-touch even at high ARR
- AX is a spectrum calibrated per customer, per lifecycle stage — not a rigid tier

---

## Task Priority in Practice

| Priority | CS Trigger | Examples |
|----------|-----------|---------|
| **P0** | Required Outcome blocked; AT RISK; churn signal active | ETA errors blocking planning; threatening to leave; key contact gone dark |
| **P1** | Success Milestone at risk; renewal imminent; contractual obligation | UAT failures; renewal <30 days with no confirmed terms; SLA breach |
| **P2** | Proactive expansion or retention | Customer hit milestone — upsell window open; renewal prep with 90-day runway |
| **P3** | Relationship maintenance | Monthly cadence; QBR prep; new contact onboarding; advocacy follow-up |
| **P4** | Admin | Invoice follow-up; contact record update; internal handoff note |

---

## Customer Sentiment in Practice

| Label | Meaning | Recommended Action |
|-------|---------|-------------------|
| **STABLE** | Positive or neutral vector; Required Outcome being achieved | Monitor; watch for expansion signal; re-engage if no growth in 90 days |
| **AT RISK** | Negative vector; Required Outcome blocked or churn signal active | Intervene immediately; diagnose root cause; escalate if needed |
| **IMPLEMENTATION** | Active onboarding; milestone-driven | Track milestones weekly; remove blockers proactively |
| **RENEWAL** | Contract renewal approaching | Demonstrate value; confirm expansion intent; prepare proposal |
| **EXPANSION** | Customer hit a Success Milestone; upsell logical | Initiate expansion conversation; involve AE if needed |
| **GHOST** | Key contact gone dark | P0 task; try alternate contacts; escalate to executive sponsor |

---

## The `ctx` Field — Why It Matters

The `ctx` (context) field in every task is the most important field after `next`. It answers:
1. What is the customer's Required Outcome?
2. What is their current Success Vector?
3. What is the specific blocker or opportunity?
4. What joint accountability exists?

A task without a strong `ctx` is busywork. Future-you (or another CSM) should be able to read `ctx` and understand immediately why this task exists, what's at stake, and what success looks like.

**Bad ctx**: "Customer asked about renewal pricing."
**Good ctx**: "Renewal Aug 15. ARR $120k. Customer (Acme) achieving Required Outcome — ETA accuracy down to <1.5h. Champion Sarah Lee confirmed 3-BU expansion interest on May 17 QBR. Economic buyer John Smith not yet engaged. Risk: renewal without expansion = Neutral Vector. Opportunity: logical 3-BU expansion at renewal."
