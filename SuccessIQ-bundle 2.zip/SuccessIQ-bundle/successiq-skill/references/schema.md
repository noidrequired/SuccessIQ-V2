# SuccessIQ JSON Schema (live, as actually used by the dashboard)

The database is a single `.json` file with four top-level arrays and two header
fields:

```json
{
  "version": 1,
  "exported": "2026-11-05T09:36:32.054Z",
  "customers": [ ... ],
  "contacts": [ ... ],
  "tasks": [ ... ],
  "auditLog": [ ... ]
}
```

There is **no `meta` object** — don't create one. `version` and `exported`
are stamped by the dashboard itself; a patch script should update `exported`
to the current ISO timestamp on every write, same as the dashboard does.

**Golden rule for every patch script: read the actual record you're about to
touch before deciding what fields it has.** Customer records in particular
have accumulated a lot of CRM-style metadata over time (`mrr`, `tenantIds`,
`accountId`, `contractExp`, `renewalFQ`, `forecast`, `churnRisk`,
`sentimentSummary`, `csNote`, `successMetrics`, and more) and not every
customer has identical fields — some older records use `seg`/`industry`,
some newer ones use `segment`/`region`. **Never drop or blank a field you
don't recognize — only add or update the fields your evidence actually
supports.**

---

## `customers`

One record per account, keyed by a lowercase slug `id` (there is no separate
numeric ID or `short` field — the slug *is* the ID, e.g. `"emmi"`,
`"borouge"`).

Core fields every sweep should read and may update:

| Field | Type | Notes |
|-------|------|-------|
| `id` | string | Lowercase slug, unique — the foreign key used everywhere else (`cust`) |
| `name` | string | Full account name |
| `stage` | string | **CS lifecycle state** — `Expansion` / `Steady` / `At-risk` / `Healthy`. This is the field that encodes Success Vector (see Methodology below) — not `sentiment`. |
| `sentiment` | string | `Green` / `Yellow` / `Red` — a separate account-health traffic light, distinct from `stage`. Don't conflate the two. |
| `health` | number | 0–100 health score |
| `arr` / `mrr` | string | Revenue, formatted as `"$24,449"` |
| `seg` or `segment` | string | Account tier (`enterprise` / `Enterprise` / `mid` / etc. — match whatever the record already uses) |
| `risk` | string | Current risk or opportunity statement |
| `next` | string | The single next milestone or action for the account |
| `summary` | string | Narrative account state — update on every sweep when something material changes; this is where `[YYYY-MM-DD SWEEP]` tags commonly live inline |
| `notes` | string | Separate append-only timestamped log, e.g. `"[2026-09-17 SWEEP] ..."` — some records use this instead of (or in addition to) tagging inside `summary`; follow whatever the record already does |
| `contacts` | string | Comma-separated display list of contact names (NOT the authoritative contact records — those live in the top-level `contacts` array below) |

Everything else on a customer record (`clr`, `bg`, `contractExp`,
`renewalStatus`, `renewalFQ`, `forecast`, `churnRisk`, `sentimentSummary`,
`nps`, `shipMethod`, `tenantIds`, `accountId`, `accountOwner`,
`economicBuyer`, `mainPoc`, `earlierCsm`, `cadence`, `upsell`, `consumption`,
`lastActivity`, `csNote`, `successMetrics`, etc.) is dashboard/CRM metadata.
Leave it untouched unless your evidence specifically updates it.

---

## `contacts` (top-level array)

One record per person, linked to a customer by slug.

```json
{
  "id": 105,
  "name": "Johan Asting",
  "cust": "borouge",
  "designation": "Sr. Manager, SCTE Program Office (AI Champion)",
  "country": "UAE",
  "email": "johan.asting@borouge.com",
  "eb": true,
  "lastContacted": "2026-04-06",
  "notes": "Primary champion for GTT x p44 integration. ..."
}
```

| Field | Type | Notes |
|-------|------|-------|
| `id` | integer | Global auto-increment across all contacts; never reuse |
| `name` | string | Full name |
| `cust` | string | Foreign key → `customers.id` (the slug) |
| `designation` | string | Title / role in their org |
| `country` | string | Optional |
| `email` | string | Work email |
| `eb` | boolean | `true` if this person is the Economic Buyer |
| `lastContacted` | ISO date | Update whenever a sweep finds fresh contact evidence |
| `notes` | string | Timestamped, append-only |

---

## `tasks`

One record per action item.

```json
{
  "id": 11,
  "cust": "borouge",
  "title": "Resolve p44 Movement 'Current Vessel' field question",
  "pri": "P1",
  "owner": "Me",
  "status": "completed",
  "created": "2026-04-06",
  "due": null,
  "durationDays": 1,
  "ctx": "Johan Asting emailed asking if p44 Movement has a field showing only the current vessel... Required Outcome: fast, unambiguous vessel-location answers. Positive vector — resolved in one exchange.",
  "subs": [
    { "t": "Reply to Johan with 'Current Vessel' field guidance", "done": true },
    { "t": "Confirm Johan can access the field", "done": true }
  ],
  "prog": 100,
  "notes": "",
  "contactIds": [105],
  "tags": []
}
```

| Field | Type | Notes |
|-------|------|-------|
| `id` | integer | Global auto-increment across all tasks; never reuse |
| `cust` | string | Foreign key → `customers.id` (the slug) — **not** `customer_id` |
| `title` | string | Short imperative description |
| `pri` | string | `P0`–`P4` — **not** `priority` |
| `owner` | string | Usually `"Me"` unless delegated |
| `status` | string | `open` / `completed` (some archived tasks also carry `"archived": true` + `"archivedAt"`) |
| `created` | ISO date | |
| `due` | ISO date or `null` | |
| `durationDays` | number | Estimated effort/duration |
| `ctx` | string | **Must name the Required Outcome this task serves** — see Methodology below. There is no separate `next`/`type`/`source` field — fold that context into `ctx` and `notes` |
| `subs` | array of `{t, done}` | Subtasks — create at least 2 where the work has real substeps |
| `prog` | number | 0–100, generally derived from `subs` completion |
| `notes` | string | Timestamped, append-only evidence log, e.g. `[2026-09-19 SWEEP] ...` |
| `contactIds` | array of integers | Links to the relevant `contacts[].id` entries, where known |
| `tags` | array of strings | Free-form labels |

---

## `auditLog`

One entry per meaningful change, newest first (the dashboard prepends new
entries). Every patch script must append at least one summarizing entry.

```json
{
  "id": "1347",
  "ts": "2026-10-27T06:45:22.977Z",
  "actor": "You",
  "action": "Task updated",
  "details": "\"Sylvamo — Recurring monthly - Deliver Overconsumption Report\": durationDays updated",
  "custId": "sylvamo_polska_sp_z_o_o"
}
```

| Field | Type | Notes |
|-------|------|-------|
| `id` | string (numeric) | Increment from the current max — entries may be missing `id` in rare legacy cases; guard with try/except when computing the max |
| `ts` | ISO datetime | |
| `actor` | string | `"You"` for a manual edit, `"Sweep"` or similar for automated runs |
| `action` | string | Short label, e.g. `"Task updated"`, `"Customer updated"`, `"Sweep completed"` |
| `details` | string | One-line human-readable description |
| `custId` | string | The customer slug this entry relates to, or `""` if general |

---

## ID Management

```python
next_task_id    = lambda tasks: max((t["id"] for t in tasks), default=0) + 1
next_contact_id = lambda contacts: max((c["id"] for c in contacts), default=0) + 1

def next_audit_id(audit_log):
    best = 0
    for a in audit_log:
        try:
            best = max(best, int(a.get("id", 0)))
        except (TypeError, ValueError):
            continue
    return str(best + 1)
```

Customers are keyed by slug, not a numeric ID — when creating a brand-new
customer, pick a lowercase, underscore-safe slug derived from the name and
make sure it isn't already in use.

---

## Methodology: Lincoln Murphy / Sixteen Ventures mapping to real fields

Full framework in `cs_methodology.md`. Here's exactly how it maps onto the
live schema so both a manual sweep and the scheduled sweep write the same
*quality* of task, not just the same field names:

- **`ctx` must name the Required Outcome.** Never write `ctx` as just a
  restatement of the trigger email — state what business result the
  customer is trying to achieve, and how this task serves or unblocks it.
  "Reduce carrier ETA variance for shipment planning" is a Required
  Outcome; "customer asked about a field" is not.
- **`pri` (P0–P4) is derived from Success Vector + Required Outcome status**,
  not from how urgent the email sounded:
  - `P0` — Required Outcome is blocked, or the account is trending `Ghost`/`AT RISK` (negative vector)
  - `P1` — a Success Milestone is at risk, renewal is imminent, or a contractual obligation is due
  - `P2` — proactive expansion/retention at a milestone (positive vector, logical upsell)
  - `P3` — relationship maintenance (neutral vector, regular cadence)
  - `P4` — pure admin
- **`stage` changes must be evidence-based**, same bar as Sentiment Vector in
  the methodology: don't flip `stage` to `At-risk` from one bad email, and
  don't flip to `Healthy`/`Expansion` from one good one — look for a pattern
  across at least two signals, or one unambiguous one (signed termination
  notice, confirmed renewal, etc.).
- **`summary` / `notes` updates should capture the Desired Outcome
  discovery**, not just activity — if a sweep reveals a new or changed
  business goal, update the narrative, not just log the event.
