"""
patch_helper.py — SuccessIQ patch script helper utilities

Copy this boilerplate into each sweep/verify patch script.
Set SRC to the user's actual successiq.json path.
Set LABEL to a short description: "sweep", "verify", "update".

Schema note: customers are keyed by a lowercase slug `id` (no separate
numeric ID + "short" field). Tasks and contacts reference that slug via
`cust`. There is no `meta` object — use the top-level `exported` timestamp
instead. See references/schema.md for the full field list and how each
field maps to Lincoln Murphy's CS methodology (ctx = Required Outcome,
pri = Success Vector status, stage = Success Vector direction).
"""

import json
import shutil
import os
import glob
from datetime import datetime, timedelta

# ── Configuration ─────────────────────────────────────────────────────────────
SRC = "/path/to/successiq.json"     # ← FILL IN: user's actual path
LABEL = "sweep"                      # ← FILL IN: "sweep" / "verify" / "update"

BACKUP_DIR = os.path.join(os.path.dirname(SRC), "backups")
STAMP = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
BACKUP = os.path.join(BACKUP_DIR, f"successiq_before-{LABEL}_{STAMP}.json")
TODAY = datetime.now().strftime("%Y-%m-%d")

# ── Backup + 30-day cleanup ───────────────────────────────────────────────────
os.makedirs(BACKUP_DIR, exist_ok=True)
shutil.copy2(SRC, BACKUP)
print(f"[BACKUP] {BACKUP}")

cutoff = datetime.now() - timedelta(days=30)
removed = 0
for f in glob.glob(os.path.join(BACKUP_DIR, "successiq_before-*.json")):
    if datetime.fromtimestamp(os.path.getmtime(f)) < cutoff:
        os.remove(f)
        removed += 1
if removed:
    print(f"[CLEANUP] Removed {removed} backup(s) older than 30 days")

# ── Load ──────────────────────────────────────────────────────────────────────
with open(SRC) as fh:
    data = json.load(fh)

tasks     = data["tasks"]
contacts  = data["contacts"]
customers = data["customers"]
audit_log = data.setdefault("auditLog", [])

# ── Helpers ───────────────────────────────────────────────────────────────────

def find_task(tid):
    """Return a task dict by ID, or None if not found."""
    return next((t for t in tasks if t["id"] == tid), None)


def find_customer(slug):
    """Return a customer dict by its slug `id`, or None if not found."""
    return next((c for c in customers if c["id"] == slug), None)


def find_contact_by_email(email):
    """Return a contact dict by email (case-insensitive), or None."""
    email_lower = email.lower()
    return next((c for c in contacts if c.get("email", "").lower() == email_lower), None)


def find_contact_by_name(frag):
    """Return the first contact whose name contains frag (case-insensitive), or None."""
    frag = frag.lower()
    return next((c for c in contacts if frag in c.get("name", "").lower()), None)


def append_note(obj, text):
    """
    Append a timestamped note to any object's 'notes' field.
    Usage: append_note(task, f"[{TODAY} SWEEP] Note text here.")
    """
    existing = obj.get("notes") or ""
    if existing and not existing.endswith(" "):
        existing += " "
    obj["notes"] = existing + text


def next_task_id():
    """Return next available task ID."""
    return max((t["id"] for t in tasks), default=0) + 1


def next_contact_id():
    """Return next available contact ID."""
    return max((c["id"] for c in contacts), default=0) + 1


def next_audit_id():
    """Return next available auditLog ID (string). Tolerant of malformed/missing ids."""
    best = 0
    for a in audit_log:
        try:
            best = max(best, int(a.get("id", 0)))
        except (TypeError, ValueError):
            continue
    return str(best + 1)


def log_audit(action, details, cust_id=""):
    """Prepend one auditLog entry (dashboard shows newest first)."""
    audit_log.insert(0, {
        "id": next_audit_id(),
        "ts": datetime.utcnow().isoformat() + "Z",
        "actor": "Sweep" if LABEL == "sweep" else "You",
        "action": action,
        "details": details,
        "custId": cust_id,
    })


def new_task(cust, title, pri, ctx, due=None, duration_days=1, owner="Me",
             subs=None, contact_ids=None, tags=None, notes=""):
    """
    Build and append a new task dict with all required fields.

    `ctx` MUST name the customer's Required Outcome and how this task
    serves/unblocks it (Lincoln Murphy methodology — see cs_methodology.md).
    `pri` must follow from Required Outcome / Success Vector status, not
    from how urgent the trigger looked.

    Example:
        t = new_task(
            cust="acme",
            title="Confirm renewal terms",
            pri="P1",
            ctx="Required Outcome: lock renewal before Jun 1 budget freeze. "
                "ARR $120k. Champion confirmed expansion interest — positive vector.",
            due="2026-06-01",
            subs=[{"t": "Send renewal proposal", "done": False},
                  {"t": "Confirm terms", "done": False}],
        )
    """
    tid = next_task_id()
    task = {
        "id": tid,
        "cust": cust,
        "title": title,
        "pri": pri,
        "owner": owner,
        "status": "open",
        "created": TODAY,
        "due": due,
        "durationDays": duration_days,
        "ctx": ctx,
        "subs": subs or [],
        "prog": 0,
        "notes": notes,
        "contactIds": contact_ids or [],
        "tags": tags or [],
    }
    tasks.append(task)
    return task


def new_contact(cust, name, email, designation="", country="", eb=False, notes=""):
    """
    Build and append a new contact.

    Example:
        c = new_contact(
            cust="acme",
            name="Sarah Lee",
            email="sarah.lee@acme.com",
            designation="VP Operations",
            eb=True,
        )
    """
    cid = next_contact_id()
    contact = {
        "id": cid,
        "name": name,
        "cust": cust,
        "designation": designation,
        "country": country,
        "email": email,
        "eb": eb,
        "lastContacted": TODAY,
        "notes": notes,
    }
    contacts.append(contact)
    return contact


# ── Mutations go here ─────────────────────────────────────────────────────────
changes = []

# ── Close a task ──────────────────────────────────────────────────────────────
# t = find_task(42)
# if t:
#     t["status"] = "completed"
#     append_note(t, f"[{TODAY} SWEEP] Closed — confirmed resolved via email from sarah@acme.com.")
#     changes.append("CLOSE #42: Renewal proposal — accepted and signed")

# ── Update a task's due date ──────────────────────────────────────────────────
# t = find_task(55)
# if t:
#     t["due"] = "2026-06-15"
#     append_note(t, f"[{TODAY} SWEEP] Due date extended from Jun 1 → Jun 15. Customer requested more time.")
#     changes.append("UPDATE #55: Due date bumped Jun 1 → Jun 15")

# ── New task (ctx names the Required Outcome — see new_task() docstring) ─────
# t = new_task(
#     cust="acme",
#     title="Confirm renewal terms and send proposal",
#     pri="P1",
#     ctx="Required Outcome: lock renewal before Jun 1 budget freeze. ARR $120k. "
#         "Champion confirmed expansion interest on May 17 QBR — positive vector.",
#     due="2026-06-01",
#     subs=[{"t": "Send 3-BU expansion proposal", "done": False}],
# )
# changes.append(f"NEW TASK #{t['id']}: Acme — confirm renewal terms")

# ── New contact ───────────────────────────────────────────────────────────────
# c = new_contact(
#     cust="acme",
#     name="John Smith",
#     email="john.smith@acme.com",
#     designation="CFO",
#     eb=True,
#     notes=f"[{TODAY} SWEEP] Appeared on renewal email thread May 19.",
# )
# changes.append(f"NEW CONTACT #{c['id']}: John Smith (CFO, Acme)")

# ── Update customer summary / stage (stage change needs a real evidence pattern) ─
# cust = find_customer("acme")
# if cust:
#     cust["summary"] = "Live on TMS integration since Jan 2026. ETA accuracy <1.5h achieved. Expansion conversation underway — 3-BU upsell targeted at renewal Aug 15."
#     cust["stage"] = "Expansion"
#     append_note(cust, f"[{TODAY} SWEEP] Stage → Expansion — confirmed upsell conversation, positive vector two sweeps running.")
#     changes.append("STAGE UPDATE: acme → Expansion, summary refreshed")


# ── Audit log + write ─────────────────────────────────────────────────────────
if changes:
    log_audit(f"Sweep completed" if LABEL == "sweep" else f"{LABEL.title()} completed",
              f"{len(changes)} changes: " + "; ".join(changes)[:500])
data["exported"] = datetime.utcnow().isoformat() + "Z"
with open(SRC, "w") as fh:
    json.dump(data, fh, ensure_ascii=True, indent=2)

# ── Report ────────────────────────────────────────────────────────────────────
print(f"\n{'='*60}")
print(f"SUCCESSIQ PATCH ({LABEL.upper()}) — {len(changes)} changes")
print(f"{'='*60}")
for i, c in enumerate(changes, 1):
    print(f"  {i:02d}. {c}")

with open(SRC) as fh:
    v = json.load(fh)
open_t = [t for t in v["tasks"] if t.get("status") == "open"]
print(f"\n[VERIFY] Tasks: {len(v['tasks'])} | Open: {len(open_t)} | Contacts: {len(v['contacts'])} | Customers: {len(v['customers'])}")
print(f"[BACKUP] {BACKUP}")
