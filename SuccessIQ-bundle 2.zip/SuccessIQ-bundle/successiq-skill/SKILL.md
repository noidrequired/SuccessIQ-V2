---
name: successiq
description: "SuccessIQ is a CS operating system for Customer Success Managers. Use this skill whenever the user wants to: run a sweep (review recent emails/Slack/Zoom to update their customer task list), check their CS status (open tasks, at-risk accounts), verify tasks for a specific customer, generate a customer timeline, or initialize a new SuccessIQ database. Trigger on any mention of 'sweep', 'my accounts', 'at-risk customers', 'open tasks', 'CSM tasks', 'SuccessIQ', or requests to check in on customers. Also trigger when the user says things like 'what do I need to do today', 'catch me up on my accounts', 'update my task list from email', or 'what happened with [customer name]'. This skill is for CSMs — anyone managing customer relationships, renewals, onboarding, or expansions."
---

# SuccessIQ — CS Operating System

SuccessIQ helps Customer Success Managers track customers, tasks, and contacts in a single JSON file, kept current by regular sweeps from Outlook, Slack, and Zoom. The methodology follows Lincoln Murphy's Desired Outcome framework — every task is grounded in a customer's business goal, not just a product action.

Read `references/cs_methodology.md` for the full framework. Read `references/schema.md` for the complete JSON data model. Read `references/sweep_workflow.md` for the detailed sweep procedure.

---

## Commands

### `init` — Initialize a new SuccessIQ database
**Trigger phrases:** "initialize SuccessIQ", "set up my SuccessIQ", "create my CS database", "start fresh"

Ask the user:
1. Their name (recorded as the first `auditLog` entry, since there's no `meta` object in this schema)
2. Where they want to save the database (default: their workspace folder as `successiq.json`)

Copy the blank template from `templates/blank_database.json` (top-level `version`/`exported`/`customers`/`contacts`/`tasks`/`auditLog` — no `meta` object), stamp `exported` with the current timestamp, append one `auditLog` entry noting the database was created for them, and write it to the requested location. Confirm the path and remind them to run a sweep to start populating their customers and tasks.

---

### `sweep` — Pull recent activity and update tasks
**Trigger phrases:** "run my sweep", "catch me up", "update my tasks", "what happened in the last [N] hours/days", "sync from email"

This is the core workflow. Follow the full procedure in `references/sweep_workflow.md`.

Short version:
1. Establish time window (default: last 48 hours; honor what the user specifies)
2. Load the user's JSON database
3. Search Outlook **received** — customer emails, support tickets, escalations, inbound signals
4. Search Outlook **sent** — equally important; sent mail reveals commitments the CSM has made, next steps promised, and escalations raised internally
5. Search Outlook for **Clari post-call summaries** — search `from:notifications@clari.com` or subject `"summary of your call"`; these contain meeting action items and decisions that exist nowhere else
6. Search Slack for relevant threads in the window
7. Check Zoom for recent customer-facing meetings (use `get_meeting_assets` to pull notes and action items)
8. Identify: new contacts, task closures, task updates, new tasks, customer summary updates
9. Write a Python patch script and execute it (see Patch Script Pattern below)
10. Report all changes

---

### `status` — Show current CS state
**Trigger phrases:** "show my status", "what's open", "what are my priorities", "AT RISK customers", "what do I need to do today"

Load the JSON and surface:
- **At-risk / P0 tasks** — must be at the top, with customer name, task title (`pri`), and customer `next` field
- **Due today or overdue** — any open task with `due ≤ today`
- **Open task count by customer** — who has the most open items (group tasks by `cust`)
- **At-risk customers** — any customer with `stage = At-risk`
- **Customers with a near-term renewal** — use the `next` / `contractExp` / `renewalFQ` fields where present, sorted by date

Format as a clean summary, not a raw table dump. The CSM should be able to read this in 90 seconds and know exactly what to do first.

---

### `verify` — Audit tasks for a specific customer
**Trigger phrases:** "verify [customer]", "check [customer] tasks", "are [customer] tasks up to date", "audit [customer]"

1. Load the JSON and pull all tasks + contacts for the named customer
2. Search Outlook email (by customer domain or contact names) for the last 30 days
3. Search Slack for the customer name
4. Check Zoom for any recent meetings with customer attendees
5. Compare evidence to task state — flag anything stale, completed without being closed, or missing
6. Propose specific updates: what to close, what to update, what new tasks to create
7. Ask the user to confirm before patching

---

### `timeline` — Generate a latest-first activity timeline
**Trigger phrases:** "timeline for [customer]", "what happened with [customer]", "history of [customer]", "catch me up on [customer]"

Pull all evidence for the customer from:
- Task history (notes fields, sorted by timestamp)
- Contact records
- Customer summary
- Outlook email (last 60 days by default — honor user's specified window)
- Slack search
- Zoom meeting notes

Format as plain text, latest first:
```
MM/DD/YYYY: [Your name]: What happened — short, factual, one line per event
```
No bullets. Each line independently understandable. Concise — skip greetings, pleasantries, and thread repetition.

---

## Data Model (Summary)

The SuccessIQ database is a single JSON file. Full schema in `references/schema.md` — **always treat that file, and the live `successiq.json` itself, as the source of truth** over this summary.

```
{
  "version":   1,
  "exported":  ISO timestamp — update on every write,
  "customers": [ { id (slug), name, stage, sentiment, health, arr/mrr, seg/segment,
                   risk, next, summary, notes, contacts, ...CRM metadata } ]
  "contacts":  [ { id, name, cust (slug), designation, country, email, eb,
                   lastContacted, notes } ]
  "tasks":     [ { id, cust (slug), title, pri, owner, status, created, due,
                   durationDays, ctx, subs [{t, done}], prog, notes,
                   contactIds, tags } ]
  "auditLog":  [ { id, ts, actor, action, details, custId } ]
}
```

There is **no `meta` object** in the live schema — don't create one. Customers are keyed by a lowercase slug `id` (not a numeric ID + separate `short` field), and tasks/contacts reference that slug via `cust`, not `customer_id`.

**IDs**: Always increment from the current max. Never reuse IDs.
```python
next_task_id    = max((t["id"] for t in tasks), default=0) + 1
next_contact_id = max((c["id"] for c in contacts), default=0) + 1
def next_audit_id(audit_log):
    best = 0
    for a in audit_log:
        try: best = max(best, int(a.get("id", 0)))
        except (TypeError, ValueError): continue
    return str(best + 1)
```

**Notes field convention**: Always append, never overwrite. Format each entry as `[YYYY-MM-DD SWEEP]`, `[YYYY-MM-DD MEETING]`, or `[YYYY-MM-DD VERIFY]`. Separate entries with a space. Preserve old notes exactly.

**`stage` labels** (the CS lifecycle field — distinct from the separate `sentiment` Green/Yellow/Red indicator): `Healthy | Steady | Expansion | At-risk`

**Priority**: `P0` → `P1` → `P2` → `P3` → `P4`, derived from Required Outcome / Success Vector status — see CS Methodology section below, and the field-by-field mapping in `references/schema.md`.

---

## Patch Script Pattern

When modifying the JSON, always write and execute a Python patch script. Never edit the JSON directly in the conversation — patch scripts are auditable, reversible, and safe.

```python
import json, shutil, os, glob
from datetime import datetime, timedelta

SRC = "/path/to/successiq.json"   # ← use user's actual path
BACKUP_DIR = os.path.join(os.path.dirname(SRC), "backups")
STAMP = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
LABEL = "sweep"                   # ← change per operation: sweep / verify / update
BACKUP = os.path.join(BACKUP_DIR, f"successiq_before-{LABEL}_{STAMP}.json")

# --- Backup ---------------------------------------------------------------
os.makedirs(BACKUP_DIR, exist_ok=True)
shutil.copy2(SRC, BACKUP)

# --- 30-day cleanup -------------------------------------------------------
cutoff = datetime.now() - timedelta(days=30)
for f in glob.glob(os.path.join(BACKUP_DIR, "successiq_before-*.json")):
    if datetime.fromtimestamp(os.path.getmtime(f)) < cutoff:
        os.remove(f)

# --- Load ----------------------------------------------------------------
with open(SRC) as fh:
    data = json.load(fh)

tasks      = data["tasks"]
contacts   = data["contacts"]
customers  = data["customers"]
audit_log  = data.setdefault("auditLog", [])

# --- Helpers -------------------------------------------------------------
def find_task(tid):
    return next((t for t in tasks if t["id"] == tid), None)

def find_customer(slug):
    return next((c for c in customers if c["id"] == slug), None)

def find_contact_by_name(frag):
    frag = frag.lower()
    return next((c for c in contacts if frag in c["name"].lower()), None)

def append_note(obj, text):
    existing = obj.get("notes") or ""
    if existing and not existing.endswith(" "):
        existing += " "
    obj["notes"] = existing + text

def next_task_id():
    return max((t["id"] for t in tasks), default=0) + 1

def next_contact_id():
    return max((c["id"] for c in contacts), default=0) + 1

def next_audit_id():
    best = 0
    for a in audit_log:
        try: best = max(best, int(a.get("id", 0)))
        except (TypeError, ValueError): continue
    return str(best + 1)

def log_audit(action, details, cust_id=""):
    audit_log.insert(0, {
        "id": next_audit_id(), "ts": datetime.utcnow().isoformat() + "Z",
        "actor": "Sweep", "action": action, "details": details, "custId": cust_id,
    })

TODAY = datetime.now().strftime("%Y-%m-%d")

# --- Mutations go here ---------------------------------------------------
changes = []

# Close a task:
# t = find_task(42)
# if t:
#     t["status"] = "completed"
#     append_note(t, f"[{TODAY} SWEEP] Closed — [reason, with evidence].")
#     changes.append("CLOSE #42: [description]")

# New task — ctx MUST name the Required Outcome this task serves (see CS Methodology below):
# tasks.append({
#     "id": next_task_id(), "cust": "acme", "title": "Follow up on contract renewal",
#     "pri": "P1", "owner": "Me", "status": "open",
#     "created": TODAY, "due": "2026-05-25", "durationDays": 3,
#     "ctx": "Required Outcome: lock in renewal before Jun 1 budget freeze. Renewal due May 31, customer hasn't confirmed terms — neutral vector, needs re-engagement.",
#     "subs": [{"t": "Send renewal summary", "done": False}, {"t": "Confirm terms", "done": False}],
#     "prog": 0, "notes": "", "contactIds": [], "tags": [],
# })
# changes.append("NEW TASK #[id]: [description]")

# Update a customer's stage — only on real evidence, see CS Methodology below:
# cust = find_customer("acme")
# if cust:
#     cust["stage"] = "At-risk"
#     append_note(cust, f"[{TODAY} SWEEP] [evidence].")
#     changes.append("STAGE UPDATE: acme → At-risk")

# --- Audit log + write -----------------------------------------------------
if changes:
    log_audit("Sweep completed", f"{len(changes)} changes: " + "; ".join(changes)[:500])
data["exported"] = datetime.utcnow().isoformat() + "Z"
with open(SRC, "w") as fh:
    json.dump(data, fh, ensure_ascii=True, indent=2)

# --- Report --------------------------------------------------------------
print(f"\n{'='*60}")
print(f"SUCCESSIQ PATCH ({LABEL.upper()}) — {len(changes)} changes")
print(f"{'='*60}")
for i, c in enumerate(changes, 1):
    print(f"  {i:02d}. {c}")

with open(SRC) as fh:
    v = json.load(fh)
open_t = [t for t in v["tasks"] if t.get("status") == "open"]
print(f"\n[VERIFY] Tasks: {len(v['tasks'])} | Open: {len(open_t)} | Contacts: {len(v['contacts'])} | Customers: {len(v['customers'])}")
print(f"[BACKUP] {BACKUP}")
```

Always run the script via Bash and show the output to the user before summarizing.

---

## CS Methodology Quick Reference

Full framework in `references/cs_methodology.md`. **This applies identically whether the sweep is run interactively or by the scheduled daily-sweep task — the methodology is not optional, and is not satisfied just by filling in the right field names.** Key rules for task work:

**Desired Outcome = Required Outcome + Appropriate Experience**
Every task must connect to a customer business goal. A customer complaining about a feature is really telling you their Required Outcome is blocked. Always ask: *what business result is this customer trying to achieve?*

**Success Vector** (direction > snapshot) — this is what the `stage` field encodes, not a literal "vector" field:
- **Positive** → engaging, progressing, expanding → `stage: Expansion` or `Healthy`
- **Neutral** → stalled; flat renewal is not success — create re-engagement task → `stage: Steady`
- **Negative** → intervene now; diagnose root cause before responding → `stage: At-risk`
- **Ghost** → key contact dark; create a P0 task immediately → `stage: At-risk`

Only move `stage` on real evidence — a pattern across signals, or one unambiguous one (signed termination, confirmed renewal). One good or bad email is not enough.

**Task priority (`pri` field)**:
- **P0**: Required Outcome blocked / account trending Ghost or At-risk; act today. Examples: ETA errors blocking planning, UAT failures, unresolved escalations, ghosting
- **P1**: Success Milestone at risk — implementation blocker, renewal deadline imminent, contractual obligation
- **P2**: Proactive expansion / retention — logical upsell at milestone, consumption monitoring, renewal prep with runway
- **P3**: Relationship maintenance — regular cadence, QBR prep, new contact onboarding
- **P4**: Admin — invoice follow-up, contact record update, internal coordination

**`ctx` field** (why this task exists) should always answer, explicitly, in the text:
- What is the customer's Required Outcome?
- What is their current Success Vector status?
- What is the specific blocker or opportunity?
- What joint accountability exists?

A `ctx` that just restates the triggering email without naming the Required Outcome is incomplete — rewrite it.

---

## Note-Writing Conventions

- Timestamp every note entry: `[YYYY-MM-DD SWEEP]`, `[YYYY-MM-DD MEETING]`, `[YYYY-MM-DD VERIFY]`, `[YYYY-MM-DD UPDATE]`
  - Use `MEETING` specifically when the source is a Clari summary, Zoom transcript, or meeting notes — it signals the note contains spoken commitments, not just email correspondence
- One note entry per distinct event; append in chronological order (oldest first)
- Never edit or delete prior notes — only append
- Include evidence: email sender + timestamp, Slack channel, Zoom/Teams meeting name, Clari call ID
- `next` field: one concrete action, who owns it, by when if known. Example: `"Send renewal proposal to [name] by May 25. CC [manager]."`

---

## Connector Usage

| Connector | Tool | Primary Use |
|-----------|------|------------|
| Outlook | `outlook_email_search` (no sender filter) | Sweep received inbox — inbound customer signals |
| Outlook | `outlook_email_search` (`sender: [csm email]`) | Sweep sent mail — CSM commitments and next steps |
| Outlook | `outlook_email_search` (`sender: notifications@clari.com`) | Clari post-call summaries — meeting action items and decisions |
| Outlook | `outlook_calendar_search` | Upcoming renewals, QBRs, kick-offs |
| Slack | `slack_search_public_and_private` | Threads, mentions, escalations |
| Zoom | `recordings_list` | List recent customer-facing meetings |
| Zoom | `get_meeting_assets` | Pull notes, transcript summary, action items |

**All three Outlook searches are mandatory on every sweep.** Received mail shows what customers said; sent mail shows what you committed to; Clari summaries show what was decided in calls. Missing any one of them leaves blind spots.

---

## File Safety Rules

1. **Always back up** before patching. Backup goes in a `backups/` subdirectory next to the JSON.
2. **30-day cleanup**: Remove backups older than 30 days after every patch. Always keep the current backup.
3. **Never edit JSON directly** in the conversation — always use a Python patch script.
4. **Verify after patching**: re-open the JSON and confirm task / contact / customer counts.
5. **Never delete or truncate** the JSON file or the backups directory without explicit user confirmation.

---

## Getting Started (New User)

1. Install Outlook, Slack, and Zoom connectors in Cowork.
2. Say **"initialize my SuccessIQ"** to create your blank database.
3. Add your customers: "add Acme Corp to my accounts — they're an enterprise renewal due August 15."
4. Run your first sweep: **"run a sweep for the last 7 days"** to catch up on existing activity.
5. From then on, run a sweep daily or every 48 hours to keep your task list current.
